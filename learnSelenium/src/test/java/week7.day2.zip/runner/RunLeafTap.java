package runner;

import io.cucumber.testng.CucumberOptions;
import stepDef.LeafTapSpecifiedMethod;

//Cucumber Annotation to execute TestCase
@CucumberOptions(features = "src\\test\\java\\features\\LeafTapLogin.feature",
				glue = {"stepDef","hooks"},
				monochrome = true,
				publish = true,
				tags = "@Smoke")

public class RunLeafTap extends LeafTapSpecifiedMethod{

}
