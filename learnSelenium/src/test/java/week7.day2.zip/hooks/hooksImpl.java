package hooks;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import io.cucumber.java.AfterStep;
import io.cucumber.java.BeforeStep;
import stepDef.LeafTapSpecifiedMethod;

public class hooksImpl extends LeafTapSpecifiedMethod{
	
	@BeforeStep
	public void beforeEveryStep() {
		System.out.println("Running this before every step");
	}
	
	@AfterStep
	public void snapShot() throws IOException {
		File source = driver.getScreenshotAs(OutputType.FILE);
		File dest = new File("snap"+i+".png");
		FileUtils.copyFile(source, dest);
		i++;
	}

}
