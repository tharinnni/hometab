package stepDef;

import org.openqa.selenium.By;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;

public class LoginPage extends LeafTapSpecifiedMethod{
	
	//Method to type username in login page
	@Given ("Type username as {string}")
	public void UserName(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}
	
	//Method to type password in login page
	@And ("Type Password as {string}")
	public void Password(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	//Method to click loginbutton in login page
	@And ("Click on Login button")
	public void buttonLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();	
	}
	
	//Method to verify error on login Screen if Login failed
	@But ("verify Error message is displayed")
	public void ErrorText() {
		System.out.println(driver.findElement(By.xpath("(//div[@id=\"errorDiv\"]/p)[1]")).getText());
	}

}
