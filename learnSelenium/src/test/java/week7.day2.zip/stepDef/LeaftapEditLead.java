package stepDef;

import io.cucumber.java.en.Given;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class LeaftapEditLead extends LeafTapSpecifiedMethod{


	
	//Method for type firstname from test data
	@And ("Type Firstname as (.*)$")
	public void typeFistName(String firstName) {
		driver.findElement(By.xpath("((//label[text()=\"First name:\"])[3]/following::input)[1]")).sendKeys(firstName);
	}
	
	//Method to click FindLeads
	@And("Click on FindLeads")
	public void clickFindLead() {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
	}
	
	//Method for Selecting first resulting record
	@And ("Click on first resulting lead")
	public void selectFirstReult() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//div[@class=\"x-grid3-cell-inner x-grid3-col-partyId\"])[1]/a")).click();
	}

	
	//Method for Click on edit
	@And ("Click Edit")
	public void clickEdit() {
		driver.findElement(By.linkText("Edit")).click();
	}
	
	//Method for type companyname from test data
	@And ("Change the companyname as (.*)$")
	public void typeCompanyName(String companyName) {
		WebElement editcompanyName = driver.findElement(By.id("updateLeadForm_companyName"));
		editcompanyName.clear();
		editcompanyName.sendKeys(companyName);
	}
	
	//Method for click on Update in Edit lead Page
	@And ("Click on update")
	public void clickUpdate() {
		driver.findElement(By.xpath("(//input[@name=\"submitButton\"])[1]")).click();
	}
	
	//Method for verify the updated name appear on result page
	@Then ("Verify the changed name appears")
	public void verifyCompanyName() {
		System.out.println(driver.findElement(By.xpath("(//span[text()='Company Name']/following::span)[1]")).getText());
	}

}
