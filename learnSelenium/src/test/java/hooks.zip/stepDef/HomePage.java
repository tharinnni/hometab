package stepDef;

import org.openqa.selenium.By;
import io.cucumber.java.en.Given;

public class HomePage extends LeafTapSpecifiedMethod{
	
	//Method to click on CRM/SFA link
	@Given ("Click CRMSFA Link")
	public void clickCRMSFA() {
		driver.findElement(By.xpath("//a[contains(text(),'CRM/SFA')]")).click();
	}
}
