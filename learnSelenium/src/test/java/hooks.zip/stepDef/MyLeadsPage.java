package stepDef;

import org.openqa.selenium.By;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;

public class MyLeadsPage extends LeafTapSpecifiedMethod{
	
	//Click on Create Lead from link
	@And ("Click Create Leads Link")
	public void clickCreateLead() {
		driver.findElement(By.linkText("Create Lead")).click();
	}
	
	//Method for click findlead link in shortcut
	@Given ("Click Find Leads from shortcuts")
	public void clickonFindLeads() {
		driver.findElement(By.linkText("Find Leads")).click();
	}

}
