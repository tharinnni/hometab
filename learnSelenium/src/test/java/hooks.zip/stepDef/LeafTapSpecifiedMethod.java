package stepDef;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LeafTapSpecifiedMethod extends AbstractTestNGCucumberTests{
	//Declaration of Chrome driver
	public ChromeDriver driver;
	public int i;
	
	//Launch chromedriver and open LeafTap Application
	@BeforeMethod
	public void projectInitialization() {
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/login");
	}
	
	//To close the browser
	@AfterMethod
	public void shutDownBrowser() {
		driver.close();
	}

}
