package stepDef;

import org.openqa.selenium.By;

import io.cucumber.java.en.And;

public class MyHomePage extends LeafTapSpecifiedMethod{
	
	//Method for click on Leads tap
	@And ("Click Leads Tab")
	public void clickLead() {
		driver.findElement(By.linkText("Leads")).click();
	}

}
