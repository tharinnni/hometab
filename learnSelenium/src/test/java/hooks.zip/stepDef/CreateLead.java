package stepDef;

import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;

public class CreateLead extends LeafTapSpecifiedMethod{

	//Method for type company name from test data
	@When ("Type the company name as (.*)$")
	public void typeCompanyName(String companyName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
	}

	//Method for type first name from test data
	@And ("Type the first name as (.*)$")
	public void typeFirstName(String firstName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
	}

	//Method for type last name from test data
	@And ("Type the last name as (.*)$")
	public void typeLastName(String lastName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
	}

	//Method for type Deaprtment name from test data
	@And ("Type the Deaprtment Name as (.*)$")
	public void typeDepartmentName(String deptName) {
		driver.findElement(By.id("createLeadForm_departmentName")).sendKeys(deptName);
	}

	//Method for click on create lead button
	@And ("Click Create Leads Button")
	public void clickLeadsButton() {
		driver.findElement(By.className("smallSubmit")).click();
	}

	//Method for verify view leadpage
	@Then ("Verify the View Leads Page")
	public void verifyCreatedLead() {
		System.out.println(driver.getTitle());
	}
	
	//Method to Verify the homescreen after Login
	@Then ("verify home screen is displayed")
	public void verifyHomePage() {
		driver.getTitle();
	}

}
